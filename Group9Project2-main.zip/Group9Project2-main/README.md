# Group9 - Project2

Task 1-3: Yasmin Sheikh Ali, Mattéo Adrien Debiere, Johanna Seitz

Task 4: Yasmin Sheikh Ali

Task 5: Mattéo Adrien Debiere 

Task 6-8: Vaishnavi Dinesh Thorve 

Task 9: Vaishnavi Dinesh Thorve, Johanna Seitz

Task 10-11: Johanna Seitz

Task 12: Vaishnavi Dinesh Thorve 

The four of us have also done revisions and corrections on each others tasks as well. 
