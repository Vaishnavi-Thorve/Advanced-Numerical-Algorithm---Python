import numpy as np
from matplotlib import pyplot, pyplot as plt
import random
import pickle
import gzip

# activation function
def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def sigmoid_derivative(x):
    return np.exp(-x) / (np.exp(-x) + 1) ** 2


# neural network
class NeuralNetwork:
    def __init__(self, input_size, input_bias, hidden_size, hidden_bias, output_size, path_to_data):
        # constructor
        self.input_size = input_size
        self.input_bias = input_bias
        self.hidden_size = hidden_size
        self.hidden_bias = hidden_bias
        self.output_size = output_size
        self.path_to_data = path_to_data

        self.input_hidden_weights = np.random.rand(input_size, hidden_size) * 0.01          # randomly set weights
        self.hidden_output_weights = np.random.rand(hidden_size, output_size) * 0.01

        self.train_X, self.train_Y, self.test_X, self.test_Y, self.validation_X, self.validation_Y = load_data(path_to_data)

        self.train_Y = convert_to_one_hot(self.train_Y)
        self.test_Y = convert_to_one_hot(self.test_Y)
        self.validation_Y = convert_to_one_hot(self.validation_Y)


    def hiddenOutputNeuralNetwork(self, X):
        # output o_tj (after activation function), output a_tj (without)
        a_hidden = np.dot(X, self.input_hidden_weights) + self.input_bias
        o_hidden = sigmoid(a_hidden)
        return o_hidden, a_hidden

    def outputNeuralNetwork(self, hidden_output):
        # output o_tj (after activation function), output a_tj (without)
        a_output = np.dot(hidden_output, self.hidden_output_weights) + self.hidden_bias
        o_output = sigmoid(a_output)
        return o_output, a_output

    def run_neural_network(self, X):
        hidden_output, _ = self.hiddenOutputNeuralNetwork(X)
        output, _ = self.outputNeuralNetwork(hidden_output)
        return output

    def lossFunction(self, X, Y):
        loss = 0
        for i in range(len(X)):
            loss += np.linalg.norm(self.run_neural_network(X[i]) - Y[i]) ** 2
        loss = loss / (2*len(X))
        return loss


    def backPropagation(self, X, Y):
        # Forward pass
        o_hidden, a_hidden = self.hiddenOutputNeuralNetwork(X)
        o_output, a_output = self.outputNeuralNetwork(o_hidden)

        # Calculate error at output layer
        error_output = o_output - Y  # Derivative of loss w.r.t. output
        delta_output = error_output * sigmoid_derivative(a_output)  # Delta for output layer

        # Calculate error at hidden layer
        error_hidden = np.dot(delta_output, self.hidden_output_weights.T)
        delta_hidden = error_hidden * sigmoid_derivative(a_hidden)  # Delta for hidden layer

        # Gradients
        grad_hidden_output_weights = np.outer(o_hidden.T, delta_output)         # outer product to create matrix of gradients (with size of input x output)
        grad_input_hidden_weights = np.outer(X.T, delta_hidden)

        return grad_input_hidden_weights, grad_hidden_output_weights, delta_hidden, delta_output


    def update_parameters(self, grad_input_hidden_weights, grad_hidden_output_weights, learning_rate):
        self.input_hidden_weights -= learning_rate * grad_input_hidden_weights
        self.hidden_output_weights -= learning_rate * grad_hidden_output_weights



    def SGD(self, X, Y, epochs, miniBatchSize, learningRate):
        training_history = []
        for epoch in range(epochs):
            XY = list(zip(X, Y))  # keep label and data together
            random.shuffle(XY)  # randomly shuffle data

            mini_batches = [XY[k:k + miniBatchSize] for k in range(0, len(XY), miniBatchSize)]

            for mini_batch in mini_batches:
                X_mini, Y_mini = zip(*mini_batch)
                X_mini = np.array(X_mini)
                Y_mini = np.array(Y_mini)

                # Initialize gradient accumulators
                grad_input_hidden_weights = np.zeros_like(self.input_hidden_weights)
                grad_hidden_output_weights = np.zeros_like(self.hidden_output_weights)

                for i in range(len(X_mini)):
                    # Backpropagation to compute gradients
                    grad_ih, grad_ho, _, _ = self.backPropagation(X_mini[i], Y_mini[i])
                    grad_input_hidden_weights += grad_ih
                    grad_hidden_output_weights += grad_ho

                # Update weights with accumulated gradients
                self.update_parameters(grad_input_hidden_weights / len(X_mini), grad_hidden_output_weights / len(X_mini), learningRate)

            # Optionally, print the loss at every epoch
            loss = self.lossFunction(X, Y)
            print(f"Epoch {epoch}: Loss = {loss}")
            training_history.append(loss)
        return training_history

    def predict(self, X_test, Y_test):
        prediction = self.run_neural_network(X_test)
        from sklearn.metrics import accuracy_score
        print(accuracy_score(Y_test, prediction))

    def attack(self):
        return 0

def load_data(path):  # Data loading by Vaishnavi
    with gzip.open(path, 'rb') as file_contents:
        train_set, validation_set, test_set = pickle.load(file_contents, encoding='latin1')

        # x input and y gives output of the corresponding data
        train_X, train_Y = train_set
        test_X, test_Y = test_set
        validation_X, validation_Y = validation_set

        print(f"Train data shape: {train_X.shape}, Train labels shape: {train_Y.shape}")
        print(f"Sample label: {train_Y[2]}")  # This will show the integer label (0-9)

        return train_X, train_Y, test_X, test_Y, validation_X, validation_Y


def convert_to_one_hot(numbers):
    # Create an array of zeros with shape (len(numbers), 10)
    one_hot_array = np.zeros((len(numbers), 10), dtype=int)

    # Set the position of each number in the array to 1
    for i, number in enumerate(numbers):
        one_hot_array[i][number] = 1

    return one_hot_array

def plot_learning_success(learning_history):
    plt.plot(learning_history)
    plt.xlabel('Epochs')
    plt.ylabel('Loss / Average Error')
    plt.title('Learning Success per Epoch')
    plt.show()

if __name__ == "__main__":
    # just for testing the existing code
    testNetwork = NeuralNetwork(784, 1, 30, 1, 10, r'mnist.pkl.gz')
    print(testNetwork.run_neural_network(testNetwork.train_X))
    # loss of the random distribution of weights
    print(testNetwork.lossFunction(testNetwork.train_X, testNetwork.train_Y))
    
    # actual training of the neural network
    history = testNetwork.SGD(testNetwork.train_X,testNetwork.train_Y,10,1,0.01)
    plot_learning_success(history)
    testNetwork.predict(testNetwork.validation_X, testNetwork.validation_Y)