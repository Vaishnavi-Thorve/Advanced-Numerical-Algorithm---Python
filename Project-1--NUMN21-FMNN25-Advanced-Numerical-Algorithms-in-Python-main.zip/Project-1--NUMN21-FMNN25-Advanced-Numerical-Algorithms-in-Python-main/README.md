# Project-1--NUMN21-FMNN25-Advanced-Numerical-Algorithms-in-Python
Contribution of the members to the Project:

Task 1: Johanna Seitz & Vaishnavi Dinesh Thorve

Task 2: Mattéo Adrien Debiere 

Task 3: Mattéo Adrien Debiere 

Task 4: Johanna Seitz & Mattéo Adrien Debiere

Task 5: Yasmin Sheikh Ali 

Task 6: Yasmin Sheikh Ali & Johanna Seitz & Mattéo Adrien Debiere & Vaishnavi Dinesh Thorve

P.S: Ludvig has been sick for project 1a so he couldn't contribute as much


- we have realized that we have a logical error in the training of the neural network, but didn't have the time to fix it anymore (but we're trying to do it until the presentation)
